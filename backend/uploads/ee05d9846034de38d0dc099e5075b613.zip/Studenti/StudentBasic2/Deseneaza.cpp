#include "Deseneaza.h"



Deseneaza::Deseneaza()
{
}


Deseneaza::~Deseneaza()
{
}

