#pragma once
#include "Planta.h"


using namespace Plantele;

class Mazare:public Planta
{

public:
	Mazare();
	~Mazare();
	
};

