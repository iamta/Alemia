#include "CPoint.h"

CPoint::CPoint(int x, int y):x(x),y(y)
{
}

