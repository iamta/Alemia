#pragma once
#include <stdlib.h>
class Main_menu
{
public:
	void draw();
	Main_menu();
	~Main_menu();
};

