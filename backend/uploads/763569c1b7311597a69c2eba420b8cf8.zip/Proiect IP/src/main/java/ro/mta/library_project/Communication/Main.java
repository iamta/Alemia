package ro.mta.library_project.Communication;


public class Main {
    public static void main(String[] args) {
        Client.getInstance().sendData("again");
        //SecureRandom secured= new SecureRandom();
        //int L=secured.nextInt();


    }
}