package ro.mta.library_project;

public class Main {
    public static void main(String[] args) throws Exception {

        Application.start();
    }
}
