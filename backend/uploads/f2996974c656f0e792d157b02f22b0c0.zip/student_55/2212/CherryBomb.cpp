#include "CherryBomb.h"
int CherryBomb::spawnTime = 3000;