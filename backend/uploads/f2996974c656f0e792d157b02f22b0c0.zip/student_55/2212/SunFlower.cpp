#include "SunFlower.h"
int SunFlower::spawnTime = 3000;