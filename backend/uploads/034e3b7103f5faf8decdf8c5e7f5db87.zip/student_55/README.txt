Pentru a juca:
- se ruleaza aplicatia
- se introduce numele de utilizator
- daca este un utilizator nou se seteaza parola iar daca este deja inregistrat se adauga parola
- odata intrat in joc pentru a planta o planta se va da click pe ea apoi pe casuta unde doriti sa fie plantata
- pentru a colecta banuti trebuie sa dati click pe sorii ce vor aparea pe linia de sus
- jucatorul poate pierde doar daca un zombie parcurge toata gradina


Observatii
- nu am folosit mecanism de exceptii deoarece nu am incercat sa le folosesc de cand am inceput sa lucrez la tema iar
iar adaugarea acestora dupa ar fi fost foarte dificila si nu ar fi meritat
